DoEstimationEstimatedWeights <- function(DataWideFormat, 
                                     CorrelationStructure) {
  # Create known weights;
  DataWideFormat$KnownWeight1 <- 2;
  DataWideFormat$KnownWeight2 <- 2*(DataWideFormat$R==0)+1*(DataWideFormat$R==1);  
  # that is, IF (R = 0) THEN known_wt2 = 2; ELSE known_wt2 = 1;
  DataWideFormat$KnownWeight <- DataWideFormat$KnownWeight1 * DataWideFormat$KnownWeight2; 
  # Create estimated weights.;
  # Estimate Stage 1 weight:
  DataWideFormat$A1DummyCoded <- 0*(DataWideFormat$A1==-1)+1*(DataWideFormat$A1==+1);
  logisticModel1 <- glm(formula=A1DummyCoded ~  Y0, 
                        family=binomial,
                        data=DataWideFormat);
  DataWideFormat$p1 <- fitted(logisticModel1);
  DataWideFormat$EstimatedWeight1 <- DataWideFormat$A1DummyCoded/DataWideFormat$p1 +
    (1-DataWideFormat$A1DummyCoded)/(1-DataWideFormat$p1);
  # Estimate Stage 2 weight:
  DataWideFormat$A2DummyCoded <- 0*(DataWideFormat$A2==-1)+1*(DataWideFormat$A2==+1);
  DataWideFormat$A2DummyCoded[which(DataWideFormat$R==1)] <- NA;
  # responders were not re-randomized, so A2 is neither -1 nor +1;
  logisticModel2 <- glm(formula=A2DummyCoded ~ 
                          Y0 + Y1, 
                        family=binomial,
                        na.action=na.exclude,
                        data=DataWideFormat); 
  DataWideFormat$p2 <- fitted(logisticModel2);
  DataWideFormat$EstimatedWeight2 <- 1;     
  who.responded <- which(DataWideFormat$R==0);
  DataWideFormat$EstimatedWeight2[who.responded] <- 
    DataWideFormat$A2DummyCoded[who.responded]/DataWideFormat$p2[who.responded] +
    (1-DataWideFormat$A2DummyCoded[who.responded])/(1-DataWideFormat$p2[who.responded]);
  # Responders have a stage 2 weight of 1;  nonresponders have a stage 2 weighted which is their
  # estimated probability of getting the treatment they did in fact get.
  DataWideFormat$EstimatedWeight <- DataWideFormat$EstimatedWeight1 * DataWideFormat$EstimatedWeight2;
  # Translate wide-format dataset into a long-format dataset;
  nwaves <- 3; 
  DataLongFormat <- reshape(DataWideFormat, 
                            varying = c("Y0", "Y1", "Y2"), 
                            v.names = "Y",
                            timevar = "time", 
                            times = c(0, 1, 2), 
                            new.row.names = 1:(nwaves*nrow(DataWideFormat)),
                            direction = "long");
  # Create "replications.";
  # Replicate people who got A1=+1 and responded with R=1.  They were not
  # re-randomized, so we have to replicate their data to inform both of
  # the dynamic treatment regimens which they could have received had they
  # been re-randomized.  It is somewhat as if we are creating two clones of
  # each of them and counting each in a different treatment, because in
  # reality it is indistinguishable which one they received.
  DataLongFormat$ActualTime <- DataLongFormat$time; # because we will mess with the time variable;
  RowsToReplicate <- DataLongFormat[which(DataLongFormat$R==1),];
  RowsNotToReplicate <- DataLongFormat[which(DataLongFormat$R==0),];
  PlusOnePseudodata <- RowsToReplicate;
  PlusOnePseudodata$A2 <- 1;
  MinusOnePseudodata <- RowsToReplicate;
  MinusOnePseudodata$A2 <- -1;
  MinusOnePseudodata$time <- MinusOnePseudodata$time + nwaves;  
  # We keep the same subject ID to show that we don't really have all those
  # new participants.  So we have to distinguish the new observations somehow,
  # and so we treat them as new waves of data on the same person.  Although
  # it seems very ad-hoc, this method has been shown to be valid.
  # Create the final analysis dataset including replicates.
  DataForAnalysis <- rbind(PlusOnePseudodata, MinusOnePseudodata, RowsNotToReplicate);
  DataForAnalysis <- DataForAnalysis[order(DataForAnalysis$id,DataForAnalysis$time),] 
  # This sorts by the variables id and time;
  DataForAnalysis$truncTime <- pmin(DataForAnalysis$ActualTime,1);
  # that is, IF ActualTime > 1 THEN truncTime = 1; ELSE truncTime = ActualTime;
  DataForAnalysis$TSince1 <- pmax(DataForAnalysis$ActualTime-1,0);
  # that is, IF ActualTime > 1 THEN TSince1 = ActualTime - 1; ELSE TSince1 = 0; 
  DataForAnalysis$wave <- DataForAnalysis$time + 1; 
  # because time 0 is actually wave 1;
  #  Do analysis with GEE
  if (tolower(CorrelationStructure)=="independence") {
    GEEOutput <- geeglm(formula = Y ~ truncTime +
                          TSince1 +
                          truncTime:A1 + 
                          TSince1:A1 +
                          TSince1:A2 +
                          TSince1:A1:A2,  
                        id=id,
                        weights = EstimatedWeight,    
                        data=DataForAnalysis,
                        corstr = "independence");
    rho <- 0;
    BlockWorkCorr <- diag(as.vector(rep(1,nwaves)));
    WorkCorr <- rbind(cbind(BlockWorkCorr,0*BlockWorkCorr),cbind(0*BlockWorkCorr,BlockWorkCorr)); 
  } else {
    GEEIndependent <- geeglm(formula = Y ~  truncTime +
                               TSince1 +
                               truncTime:A1 + 
                               TSince1:A1 +
                               TSince1:A2 +
                               TSince1:A1:A2,  
                             id=id,  
                             weights = EstimatedWeight,
                             data=DataForAnalysis,
                             corstr = "independence" ); 
    # "Estimate marginal residual variance under each regime" 
    stopifnot(length(GEEIndependent$resid)==nrow(DataForAnalysis)); # make sure that geeglm didn't drop any rows because of missing data;
    # Create a table of estimated variances indexed by A1, A2, and ActualTime.;
    VarianceEstimatesByRegimenAndTime <- expand.grid(A1=unique(DataForAnalysis$A1),
                                                     A2=unique(DataForAnalysis$A2),
                                                     ActualTime=unique(DataForAnalysis$ActualTime),
                                                     VarianceEstimate=NA);
    for (i in 1:nrow(VarianceEstimatesByRegimenAndTime)) {
      TheseRows <- which( (DataForAnalysis$A1==VarianceEstimatesByRegimenAndTime$A1[i])&
                            (DataForAnalysis$A2==VarianceEstimatesByRegimenAndTime$A2[i])&
                            (DataForAnalysis$ActualTime==VarianceEstimatesByRegimenAndTime$ActualTime[i]) );   
      VarianceEstimatesByRegimenAndTime$VarianceEstimate[i] <- 
        weighted.mean(x=(GEEIndependent$resid[TheseRows]^2),w=DataForAnalysis$EstimatedWeight[TheseRows]);
    }  
    # Now create a smaller table of estimated variances indexed only by A1 and A2.
    CovarianceEstimatesByRegimen <- expand.grid(A1=unique(DataForAnalysis$A1),
                                                A2=unique(DataForAnalysis$A2), 
                                                VarianceEstimate=NA,
                                                CrossCorrelationEstimate=NA);
    for (i in 1:nrow(CovarianceEstimatesByRegimen)) {
      TheseRows <- which( (VarianceEstimatesByRegimenAndTime$A1==CovarianceEstimatesByRegimen$A1[i])&
                            (VarianceEstimatesByRegimenAndTime$A2==CovarianceEstimatesByRegimen$A2[i])  );   
      CovarianceEstimatesByRegimen$VarianceEstimate[i] <- 
        mean(VarianceEstimatesByRegimenAndTime$VarianceEstimate[TheseRows]);
    }   
    VarianceEstimatePooled <- mean(CovarianceEstimatesByRegimen$VarianceEstimate);
    # "Estimate off-diagonal within-person correlation"
    for (i in 1:nrow(CovarianceEstimatesByRegimen)) {  # regimen index;
      MeanResidualCrossProductsPerSubjectForThisRegimen <- NULL;
      WeightsForThisRegimen <- NULL;
      ThisRegimen <- which( (DataForAnalysis$A1==CovarianceEstimatesByRegimen$A1[i])&
                              (DataForAnalysis$A2==CovarianceEstimatesByRegimen$A2[i]));
      if (tolower(CorrelationStructure)=="exchangeable") {
        for (j in unique(DataForAnalysis$id)) { # subject index; 
          ThisSubjectAndRegimen <- which( (DataForAnalysis$A1==CovarianceEstimatesByRegimen$A1[i])&
                                            (DataForAnalysis$A2==CovarianceEstimatesByRegimen$A2[i]) &
                                            (DataForAnalysis$id==j));
          if (length(ThisSubjectAndRegimen)>0) {
            tempCrossProducts <- crossprod(t(GEEIndependent$resid[ThisSubjectAndRegimen]))[
              upper.tri(crossprod(t(GEEIndependent$resid[ThisSubjectAndRegimen])))]; 
            MeanResidualCrossProductsPerSubjectForThisRegimen <- c(MeanResidualCrossProductsPerSubjectForThisRegimen,
                                                                   mean(tempCrossProducts)); 
            WeightsForThisRegimen <- c(WeightsForThisRegimen, DataForAnalysis[ThisSubjectAndRegimen[1],]$EstimatedWeight);
            # assumes all observations per subject have the same weight;
          }       
        }
      }
      if (tolower(CorrelationStructure)=="ar-1") {
        for (j in unique(DataForAnalysis$id)) { # subject index; 
          ThisSubjectAndRegimen <- which( (DataForAnalysis$A1==CovarianceEstimatesByRegimen$A1[i])&
                                            (DataForAnalysis$A2==CovarianceEstimatesByRegimen$A2[i]) &
                                            (DataForAnalysis$id==j));
          if (length(ThisSubjectAndRegimen)>0) {
            tempVector <- GEEIndependent$resid[ThisSubjectAndRegimen];
            tempCrossProducts <- tempVector[1:(length(tempVector)-1)] * tempVector[2:length(tempVector)]; 
            MeanResidualCrossProductsPerSubjectForThisRegimen <- c(MeanResidualCrossProductsPerSubjectForThisRegimen,
                                                                   mean(tempCrossProducts)); 
            WeightsForThisRegimen <- c(WeightsForThisRegimen, DataForAnalysis[ThisSubjectAndRegimen[1],]$EstimatedWeight);
            # assumes all observations per subject have the same weight;
          }       
        }
      }
      CovarianceEstimatesByRegimen$CrossCorrelationEstimate[i] <- weighted.mean(x=MeanResidualCrossProductsPerSubjectForThisRegimen,
                                                                                w=WeightsForThisRegimen)/ 
                 CovarianceEstimatesByRegimen$VarianceEstimate[i];
    } 
    CrossCorrelationEstimatePooled <- mean(CovarianceEstimatesByRegimen$CrossCorrelationEstimate);
    # Print preliminary results;
    # Construct WorkCorr (working correlation matrix) 
    rho <- CrossCorrelationEstimatePooled;  
    if (tolower(CorrelationStructure)=="exchangeable") {
      BlockWorkCorr <- diag(as.vector(rep(1-rho,nwaves)))+matrix(rho,nwaves,nwaves);
    }
    if (tolower(CorrelationStructure)=="ar-1") {
      BlockWorkCorr <- matrix(0,nwaves,nwaves);
      for (thisRow in 1:nrow(BlockWorkCorr)) {
        for (thisColumn in 1:ncol(BlockWorkCorr)) {
          BlockWorkCorr[thisRow,thisColumn] <- rho^abs(thisRow-thisColumn);
        }
      }
    }  
    WorkCorr <- rbind(cbind(BlockWorkCorr,0*BlockWorkCorr),cbind(0*BlockWorkCorr,BlockWorkCorr)); 
    WorkCorrAsZCor <- fixed2Zcor(cor.fixed=WorkCorr, 
                             id=DataForAnalysis$id,  
                             waves=DataForAnalysis$wave); 
    GEEOutput <- geeglm(formula = Y ~ truncTime +
                        TSince1 +
                        truncTime:A1 + 
                        TSince1:A1 +
                        TSince1:A2 +
                        TSince1:A1:A2,  
                        id=id,  
                        weights = EstimatedWeight,
                        data=DataForAnalysis,
                        corstr = "fixed",
                        zcor=WorkCorrAsZCor);   
  }
  # Convert the regression coefficients estimates into the desired linear contrast estimates.; 
  GEECoefficients <- coef(GEEOutput);
  GEECovarianceMatrix <- GEEOutput$geese$vbeta;
  ##############################################################
  # STANDARD ERROR CALCULATION;
  # Step 1 : Define the contrast coefficients and convert the regression coefficient
  #         estimates into the desired linear contrast estimates. 
  ##############################################################  
  colnames(ContrastCoefficients) <- names(coef(GEEOutput));
  ContrastEstimates <- ContrastCoefficients%*%GEECoefficients;  # Note the matrix multiplication;
  VarianceEstimate <- summary(GEEOutput)$dispersion["(Intercept)","Estimate"]; 
  # Step 2: Calculate the score functions X'(Y-mu) from the propensity models.  
  # This is done with the unreplicated data.          
  nsub <- nrow(DataWideFormat);
  PredictorsLogistic1 =  DataWideFormat$Y0; 
  PredictorsLogistic2 = cbind( DataWideFormat$Y0,
                               DataWideFormat$Y1); 
  scoreAlpha1 <- cbind(1,PredictorsLogistic1) * (DataWideFormat$A1DummyCoded - DataWideFormat$p1);
  residuals2 <- DataWideFormat$A2DummyCoded - DataWideFormat$p2;
  residuals2[which(is.na(residuals2))] <- 0;  # This excludes the responders from the model for stage 2;
  scoreAlpha2 <- cbind(1,PredictorsLogistic2) * residuals2; 
  # Step 3: Finish calculating the standard errors.
  # This is done with the replicated data. 
  predictors <- cbind(DataForAnalysis$truncTime,
                      DataForAnalysis$TSince1,
                      DataForAnalysis$truncTime*DataForAnalysis$A1,
                      DataForAnalysis$TSince1*DataForAnalysis$A1,
                      DataForAnalysis$TSince1*DataForAnalysis$A2,
                      DataForAnalysis$TSince1*DataForAnalysis$A1*DataForAnalysis$A2);
  predictors <- cbind(1,predictors); # add intercept column;
  # Construct "matrixI," the empirical covariance matrix of the 
  # GEE coefficients, and "matrixJ", their model-based covariance matrix. 
  # "I" and "J" are the notation used in Xi Lu's code (I stands for "information" as in
  # Fisher information matrix.  They don't represent the usual I and J matrices which 
  #	are the identity (diagonal) and all-ones matrix respectively. */
  resid <- GEEOutput$residuals;
  nobs <- nrow(predictors);
  stopifnot(length(resid)==nobs); # try to make sure nothing has gone wrong;
  matrixJ <- matrix(0,ncol(predictors),ncol(predictors));
  U <- matrix(0,nsub,ncol(predictors));
  # The rows of U are the score function for each subject (derivative of that subject's
  # log-pseudo-likelihood contribution with respect to beta), with each subject in the original 
  # data set having one row. */   
  indicesNextSubject <- 1:nwaves;  
  for (i in 1:nsub) {
    indicesThisSubject <- indicesNextSubject;
    weightThisSubject <- DataForAnalysis$KnownWeight[indicesThisSubject[1]];
    # The weights are the same for all observations within the 
    # subject, so we just read the first one.
    # I'm following Xi Lu's code in using the known weight here instead of the 
    # estimated weight.  I am not sure why she does this.
    residualsThisSubject <- resid[indicesThisSubject];
    predictorsThisSubject <- predictors[indicesThisSubject,] ;  
    errorThisSubject <- weightThisSubject * t(predictorsThisSubject) %*% solve(BlockWorkCorr) %*% residualsThisSubject;
    # errorThisSubject is a k by 1 vector for this subject's score function, 
    # here k is ncol(predictors). 
    if (indicesThisSubject[nwaves] == nobs) {
      # This is the case where the current observations are for the last individual,
      # so no more observations are forthcoming. 
      U[i,] <- t(errorThisSubject);
      thisMatrixJ <- weightThisSubject * t(predictorsThisSubject)%*%solve(BlockWorkCorr)%*%predictorsThisSubject;
      # contribution to J from this subject;
      matrixJ <- matrixJ + thisMatrixJ;
    } else {
      if (DataForAnalysis$wave[[indicesThisSubject[nwaves]+1]] == 1) {
        # This is the case where the next observations are from an actual new individual. */
        U[i,] <- t(errorThisSubject);
        thisMatrixJ = weightThisSubject * t(predictorsThisSubject)%*%solve(BlockWorkCorr)%*%predictorsThisSubject;
        # contribution to J from this subject;
        matrixJ <- matrixJ + thisMatrixJ;
        indicesNextSubject <- (indicesThisSubject[nwaves]+1):(indicesThisSubject[nwaves]+nwaves); 
      } 
      if  (DataForAnalysis$wave[[indicesThisSubject[nwaves]+1]] == nwaves+1) {
        # This is the case where the next observations are a replicate of this individual.;
        indicesReplicate <- (indicesThisSubject[nwaves]+1):(indicesThisSubject[nwaves]+nwaves);
        residReplicate <- resid[indicesReplicate];
        predictorsReplicate <- predictors[indicesReplicate,];
        errorReplicate <- weightThisSubject * t(predictorsReplicate)%*%solve(BlockWorkCorr)%*%residReplicate;
        U[i,] <- t(errorThisSubject + errorReplicate);
        thisMatrixJ <- weightThisSubject * t(predictorsThisSubject)%*%solve(BlockWorkCorr)%*%predictorsThisSubject + 
          weightThisSubject * t(predictorsReplicate)%*%solve(BlockWorkCorr)%*%predictorsReplicate;
        matrixJ <- matrixJ + thisMatrixJ;
        indicesNextSubject <- (indicesReplicate[nwaves]+1):(indicesReplicate[nwaves]+nwaves);
      }
      if ((DataForAnalysis$wave[indicesThisSubject[nwaves]+1] != 1) & 
          (DataForAnalysis$wave[indicesThisSubject[nwaves]+1] != nwaves+1) ) {
        print("Unexpected error in code or dataset;");
        print(indicesThisSubject); 
      }
    }
  }
  #  Construct the final covariance matrix estimate using an adjusted sandwich formula, 
  # and extract the standard errors.;
  matrixIKnownWeights <- (1/nsub)*t(U)%*%U;
  scores <- cbind(scoreAlpha1, scoreAlpha2);
  hat <- scores%*%solve(t(scores)%*%scores)%*%t(scores)
  # The "hat" or projection matrix of the regression of the weights on the predictors of the weights.
  Uproj <- U - hat%*%U;
  matrixI <- (1/nsub)*t(Uproj)%*%Uproj;
  matrixIAdjusted <- (nsub/(nsub-ncol(predictors)))*matrixI; # Adjust variance estimate for presence of covariates;
  matrixJ <- matrixJ/nsub;
  invJ <- solve(matrixJ);
  asymvar = (1/nsub)* invJ %*% matrixIAdjusted %*% invJ; 
  ContrastCovarianceMatrix <- ContrastCoefficients%*%asymvar%*%t(ContrastCoefficients);
  ContrastStdErrors <- sqrt(diag(as.matrix(ContrastCovarianceMatrix))); 
  return(list(GEEOutput=GEEOutput,
              ContrastEstimates=ContrastEstimates,
              ContrastStdErrors=ContrastStdErrors,
              VarianceEstimate=VarianceEstimate,
              CorrelationEstimate=rho));
}