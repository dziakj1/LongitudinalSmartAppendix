rm(list=ls(all=TRUE));    # Run this line only if you want to clear
# the workspace and start fresh; 
set.seed(42); # Set random seed
# Load needed functions and libraries:
library(geepack);
library(mvtnorm);
source("BlockSigma.R");
source("SimulateFromPathMeans3Waves.R");
source("DoEstimationEstimatedWeights.R");
# Define data-generating parameters:.
# Define number of datasets and sample size per dataset:
nSimulations <- 5000;             
N <- 500;
startTime <- Sys.time(); 
conditional.mean0.yes <- 33.52;
conditional.mean0.no <- 32.49;
conditional.mean1.plus.yes <- 31.83;
conditional.mean1.plus.no <- 30.75;
conditional.mean1.minus.yes <- 33.33;
conditional.mean1.minus.no <- 31.92;
conditional.mean2.plus.yes <- 32.57;
conditional.mean2.plus.no.plus <- 30.43;
conditional.mean2.plus.no.minus <- 27.88;
conditional.mean2.minus.yes <- 31.78;
conditional.mean2.minus.no.plus <- 31.71;
conditional.mean2.minus.no.minus <- 31.29;
print(c(conditional.mean0.yes =	conditional.mean0.yes,
        conditional.mean0.no = conditional.mean0.no,
        conditional.mean1.plus.yes = conditional.mean1.plus.yes,
        conditional.mean1.plus.no = conditional.mean1.plus.no,
        conditional.mean1.minus.yes = conditional.mean1.minus.yes,
        conditional.mean1.minus.no = conditional.mean1.minus.no,
        conditional.mean2.plus.yes = conditional.mean2.plus.yes,
        conditional.mean2.plus.no.plus = conditional.mean2.plus.no.plus,
        conditional.mean2.plus.no.minus =	conditional.mean2.plus.no.minus,
        conditional.mean2.minus.yes = conditional.mean2.minus.yes,
        conditional.mean2.minus.no.plus =	conditional.mean2.minus.no.plus,
        conditional.mean2.minus.no.minus = conditional.mean2.minus.no.minus));
prob.respond.plus <- .5;
prob.respond.minus <- .5; 
#source("PlotConditionalMeanParameters.r");
# Define contrasts;
ContrastCoefficients <- matrix(c(
  +1.0,  +1.0, +1.0, +1.0, +1.0, +1.0, +1.0,
  +1.0,  +1.0, +1.0, +1.0, +1.0, -1.0, -1.0,
  +1.0,  +1.0, +1.0, -1.0, -1.0, +1.0, -1.0,
  +1.0,  +1.0, +1.0, -1.0, -1.0, -1.0, +1.0,
  +0.0,  +0.0, +0.0, +0.0, +0.0, +2.0, +2.0,
  +0.0,  +0.0, +0.0, +2.0, +2.0, +0.0, +2.0,
  +0.0,  +0.0, +0.0, +2.0, +2.0, +2.0, +0.0,
  +0.0,  +0.0, +0.0, +2.0, +2.0, -2.0, +0.0,
  +0.0,  +0.0, +0.0, +2.0, +2.0, +0.0, -2.0,
  +0.0,  +0.0, +0.0, +0.0, +0.0, +2.0, -2.0,
  +2.0,  +1.5, +0.5, +1.5, +0.5, +0.5, +0.5,
  +2.0,  +1.5, +0.5, +1.5, +0.5, -0.5, -0.5,
  +2.0,  +1.5, +0.5, -1.5, -0.5, +0.5, -0.5,
  +2.0,  +1.5, +0.5, -1.5, -0.5, -0.5, +0.5,
  +0.0,  +0.0, +0.0, +0.0, +0.0, +1.0, +1.0,
  +0.0,  +0.0, +0.0, +3.0, +1.0, +0.0, +1.0,
  +0.0,  +0.0, +0.0, +3.0, +1.0, +1.0, +0.0,
  +0.0,  +0.0, +0.0, +3.0, +1.0, -1.0, +0.0,
  +0.0,  +0.0, +0.0, +3.0, +1.0, +0.0, -1.0,
  +0.0,  +0.0, +0.0, +0.0, +0.0, +1.0, -1.0  ),ncol=7,byrow=TRUE);
rownames(ContrastCoefficients) <- c("Final+1+1",
                                    "Final+1-1",
                                    "Final-1+1",
                                    "Final-1-1",
                                    "Final+1+1minusFinal+1-1",
                                    "Final+1+1minusFinal-1+1",
                                    "Final+1+1minusFinal-1-1",
                                    "Final+1-1minusFinal-1+1",
                                    "Final+1-1minusFinal-1-1",
                                    "Final-1+1minusFinal-1-1",
                                    "Area+1+1",
                                    "Area+1-1",
                                    "Area-1+1",
                                    "Area-1-1",
                                    "Area+1+1minusArea+1-1",
                                    "Area+1+1minusArea-1+1",
                                    "Area+1+1minusArea-1-1",
                                    "Area+1-1minusArea-1+1",
                                    "Area+1-1minusArea-1-1",
                                    "Area-1+1minusArea-1-1");
# Define correct answers for contrasts at the population level:
final.plus.plus <- prob.respond.plus *conditional.mean2.plus.yes  + (1-prob.respond.plus) *conditional.mean2.plus.no.plus;
final.plus.minus <- prob.respond.plus *conditional.mean2.plus.yes  + (1-prob.respond.plus) *conditional.mean2.plus.no.minus;
final.minus.plus <- prob.respond.minus*conditional.mean2.minus.yes + (1-prob.respond.minus)*conditional.mean2.minus.no.plus;
final.minus.minus <- prob.respond.minus*conditional.mean2.minus.yes + (1-prob.respond.minus)*conditional.mean2.minus.no.minus;
area0to1.plus  <- prob.respond.plus*(conditional.mean0.yes + (conditional.mean1.plus.yes - conditional.mean0.yes)/2)+
  (1-prob.respond.plus)*(conditional.mean0.no + (conditional.mean1.plus.no - conditional.mean0.no)/2);
area0to1.minus  <- prob.respond.minus*(conditional.mean0.yes + (conditional.mean1.minus.yes - conditional.mean0.yes)/2)+
  (1-prob.respond.minus)*(conditional.mean0.no + (conditional.mean1.minus.no - conditional.mean0.no)/2);
area1to2.plus.plus  <- prob.respond.plus*((conditional.mean1.plus.yes+conditional.mean2.plus.yes)/2)+
  (1-prob.respond.plus)*((conditional.mean1.plus.no+conditional.mean2.plus.no.plus)/2);
area1to2.plus.minus <- prob.respond.plus*((conditional.mean1.plus.yes+conditional.mean2.plus.yes)/2)+
  (1-prob.respond.plus)*((conditional.mean1.plus.no+conditional.mean2.plus.no.minus)/2);
area1to2.minus.plus  <- prob.respond.minus*((conditional.mean1.minus.yes+conditional.mean2.minus.yes)/2)+
  (1-prob.respond.minus)*((conditional.mean1.minus.no+conditional.mean2.minus.no.plus)/2);
area1to2.minus.minus <- prob.respond.minus*((conditional.mean1.minus.yes+conditional.mean2.minus.yes)/2)+
  (1-prob.respond.minus)*((conditional.mean1.minus.no+conditional.mean2.minus.no.minus)/2);
area.plus.plus <- area0to1.plus+area1to2.plus.plus;
area.plus.minus <- area0to1.plus+area1to2.plus.minus;
area.minus.plus <- area0to1.minus+area1to2.minus.plus;
area.minus.minus <- area0to1.minus+area1to2.minus.minus;
true.values.for.contrasts <- c(final.plus.plus,
                               final.plus.minus,
                               final.minus.plus,
                               final.minus.minus,
                               final.plus.plus-final.plus.minus,
                               final.plus.plus-final.minus.plus,
                               final.plus.plus-final.minus.minus,
                               final.plus.minus-final.minus.plus,
                               final.plus.minus-final.minus.minus,
                               final.minus.plus-final.minus.minus,
                               area.plus.plus,
                               area.plus.minus,
                               area.minus.plus,
                               area.minus.minus,
                               area.plus.plus-area.plus.minus,
                               area.plus.plus-area.minus.plus,
                               area.plus.plus-area.minus.minus,
                               area.plus.minus-area.minus.plus,
                               area.plus.minus-area.minus.minus,
                               area.minus.plus-area.minus.minus);
names(true.values.for.contrasts) <- c("Final +1,+1",
                                      "Final +1,-1",
                                      "Final -1,+1",
                                      "Final -1,-1", 
                                      "Final +1,+1 versus +1,-1",
                                      "Final +1,+1 versus -1,+1",
                                      "Final +1,+1 versus -1,-1",
                                      "Final +1,-1 versus -1,+1",
                                      "Final +1,-1 versus -1,-1",
                                      "Final -1,+1 versus -1,-1", 
                                      "Area +1,+1",
                                      "Area +1,-1",
                                      "Area -1,+1",
                                      "Area -1,-1",
                                      "Area +1,+1 versus +1,-1",
                                      "Area +1,+1 versus -1,+1",
                                      "Area +1,+1 versus -1,-1",
                                      "Area +1,-1 versus -1,+1",
                                      "Area +1,-1 versus -1,-1",
                                      "Area -1,+1 versus -1,-1");  
# Create data structures to hold the results of the simulations:
corr.structure.names = c("independence","exchangeable","AR-1","checkerboard");
all.contrast.estimates <- array(data=NA,
                                dim=c(4,3,2,nSimulations,nrow(ContrastCoefficients)),
                                dimnames=list(TrueStructure=corr.structure.names[1:4],
                                              FittedStructure=corr.structure.names[1:3],
                                              Weighting=c("Constant","Estimated"),
                                              Simulation=1:nSimulations,
                                              Contrast=names(true.values.for.contrasts)));
all.contrast.std.errs <- array(data=NA,
                               dim=dim(all.contrast.estimates),
                               dimnames=dimnames(all.contrast.estimates));
all.contrast.true.values <- array(data=NA,
                               dim=dim(all.contrast.estimates),
                               dimnames=dimnames(all.contrast.estimates));
all.variance.estimates <- array(data=NA,
                                dim=dim(all.contrast.estimates)[1:4],
                                dimnames=dimnames(all.contrast.estimates)[1:4]);
all.correlation.estimates <- array(data=NA,
                                   dim=dim(all.variance.estimates),
                                   dimnames=dimnames(all.variance.estimates)); 
# Begin loop of simulations:
for (thisTrueCor in 1:4) { 
  for (thisSimulation in 1:nSimulations) { 
    # Generate the simulated dataset in wide format:  
    data.wide.format <- simulate.from.path.means.3waves(N=N,
                                                        conditional.mean0.yes = conditional.mean0.yes,
                                                        conditional.mean0.no = conditional.mean0.no,
                                                        conditional.mean1.plus.yes = conditional.mean1.plus.yes,
                                                        conditional.mean1.plus.no = conditional.mean1.plus.no,
                                                        conditional.mean1.minus.yes = conditional.mean1.minus.yes,
                                                        conditional.mean1.minus.no = conditional.mean1.minus.no,
                                                        conditional.mean2.plus.yes = conditional.mean2.plus.yes,
                                                        conditional.mean2.plus.no.plus = conditional.mean2.plus.no.plus,
                                                        conditional.mean2.plus.no.minus = conditional.mean2.plus.no.minus,
                                                        conditional.mean2.minus.yes = conditional.mean2.minus.yes,
                                                        conditional.mean2.minus.no.plus = conditional.mean2.minus.no.plus,
                                                        conditional.mean2.minus.no.minus = conditional.mean2.minus.no.minus, 
                                                        prob.respond.plus = prob.respond.plus,
                                                        prob.respond.minus = prob.respond.minus,
                                                        sigma = 5,
                                                        cor.structure = corr.structure.names[thisTrueCor],
                                                        cor.parameter = .5);
    for (thisWorkingCor in 1:3) {
      # Do the analyses: 
      results <- DoEstimationEstimatedWeights(DataWideFormat=data.wide.format,
                                          CorrelationStructure=corr.structure.names[thisWorkingCor]);
      all.contrast.estimates[thisTrueCor,thisWorkingCor,1,thisSimulation,] <- results$ContrastEstimates;
      all.contrast.true.values[thisTrueCor,thisWorkingCor,1,thisSimulation,] <- true.values.for.contrasts;
      all.contrast.std.errs[thisTrueCor,thisWorkingCor,1,thisSimulation,] <- results$ContrastStdErrors;
      all.variance.estimates[thisTrueCor,thisWorkingCor,1,thisSimulation] <- results$VarianceEstimate;
      all.correlation.estimates[thisTrueCor,thisWorkingCor,1,thisSimulation] <- results$CorrelationEstimate;
      last.results <- results;
      rm(results);
    }
  }  
}


print("Estimated variance:");
print(apply(all.variance.estimates[,,1,],c(1,2),mean));

print("Estimated correlation:");
print(apply(all.correlation.estimates[,,1,],c(1,2),mean));


print("Average Absolute Bias:");
bias <- apply((all.contrast.estimates-all.contrast.true.values)[,,1,,],c(1,2,4),mean);
average.absolute.bias <- apply(abs(bias[,,15:20]),c(1,2),mean);
print(average.absolute.bias);

print("Square root of MSE (true standard error):");
rmse <- sqrt(apply(((all.contrast.estimates-all.contrast.true.values)^2)[,,1,,],c(1,2,4),mean));
average.rmse <- apply(rmse[,,15:20],c(1,2),mean);
print(average.rmse);

print("Estimated standard error:");
se <- apply((all.contrast.std.errs)[,,1,,],c(1,2,4),mean);
average.se <- apply(se[,,15:20],c(1,2),mean);
print(average.se);
  
print("Confidence interval coverage (nominal 95%):");
coverage <- apply((abs(all.contrast.estimates-all.contrast.true.values)<1.96*all.contrast.std.errs)[,,1,,],c(1,2,4),mean);
average.coverage <- apply(coverage[,,15:20],c(1,2),mean);
print(average.coverage);




finishTime <- Sys.time();
print(finishTime-startTime);
save.image("LSmartSimEstimated.Rdata");
