simulate.from.path.means.3waves <- function(
  # This code assumes that randomization occurs immediately after
  # measurement 0 for everyone, and immediately after measurement 1 for
  # people judged not to have adequate treatment response.  There are
  # measurements at time 2 and 3 but no further randomization.
  # As usual in SMART, "nonresponder" and "responder" refer to judgments
  # of whether the treatment is adequate, NOT to data being missing or
  # nonmissing.
  N,
  # total sample size
  conditional.mean0.yes,
  # baseline mean given $R=1$
  conditional.mean0.no,
  # baseline mean given $R=0$
  conditional.mean1.plus.yes,
  # stage 1 mean given $A_1=+1$ and $R=1$
  conditional.mean1.plus.no,
  # stage 1 mean given $A_1=+1$ and $R=0$
  conditional.mean1.minus.yes,
  # stage 1 mean given $A_1=-1$ and $R=1$
  conditional.mean1.minus.no,
  # stage 1 mean given $A_1=-1$ and $R=0$
  conditional.mean2.plus.yes,
  # stage 2 mean for responders given $A_1=+1$
  conditional.mean2.plus.no.plus,
  # stage 2 mean for nonresponders given $A_1=+1$, $A_2=+1$
  conditional.mean2.plus.no.minus,
  # stage 2 mean for nonresponders given $A_1=+1$, $A_2=-1$
  conditional.mean2.minus.yes,
  # stage 2 mean for responders given $A_2=-1$
  conditional.mean2.minus.no.plus,
  # stage 2 mean for nonresponders given $A_1=-1$, $A_2=+1$
  conditional.mean2.minus.no.minus,
  # stage 2 mean for nonresponders given $A_1=-1$, $A_2=-1$
  prob.respond.plus,
  # proportion of responders for $A_1=+1$
  prob.respond.minus,
  # proportion of responders for $A_1=-1$
  sigma,
  # The standard deviation of the outcomes.  For now
  # we assume (unrealistically) that the errors for the stage 0, 1,
  # and 2 outcomes are independent normal and
  # homoskedastic with a constant variance that does
  # not depend on treatment status.  
  cor.structure,
  # The correlation structure as a string: "independence","AR-1", or "exchangeable"					   
  cor.parameter
  # The correlation parameter; ignored if cor.structure is "independence"
) {
  randomization1 <- sample(x=c(+1,-1),size=N,replace=TRUE);
  # The variable "randomization1" represents $A_1$, the first randomized
  # treatment assignment, and is +1 or -1 with equal probability for
  # each subject.
  respond <- rep(NA,N);
  respond[which(randomization1==+1)] <- rbinom(n=sum(randomization1==+1),
                                               size=1,
                                               prob=prob.respond.plus);
  respond[which(randomization1==-1)] <- rbinom(n=sum(randomization1==-1),
                                               size=1,
                                               prob=prob.respond.minus);
  # The variable respond represents $R$, the "response to treatment," and is
  # coded as 0 for no and 1 for yes.  The "response to treatment"
  # can depend on $A_1$, but for now we assume unrealistically that it is
  # unrelated to $Y_0$ and to $Y_1 | A_1$.  Future code should allow a
  # relationship between $Y_1$ and $R$, either by setting the latter to
  # a thresholded version of the former, or by specifying some measure
  # of correlation.  This relationship might be relevant to statistical power,
  # and/or to the validity of the assumptions of a longitudinal model, even
  # though it is not relevant to the research questions of main interest.
  randomization2 <- rep(NA,N);
  randomization2[which(respond==0)] <- sample(x=c(+1,-1),
                                              size=sum(respond==0),
                                              replace=TRUE);
  randomization2[which(respond==1)] <- 0;
  # The variable "randomization1" represents $A_2$, the second randomized
  # treatment assignment.  It is assumed to be relevant only for subjects
  # with R=0.  It is +1 or -1 with equal probability for each such subject,
  # and coded as 0 otherwise.
  people.in.cell.yes <- which(respond==1);
  people.in.cell.no <- which(respond==0);
  people.in.cell.plus.yes <- which(randomization1==+1 & respond==1);
  people.in.cell.plus.no <- which(randomization1==+1 & respond==0);
  people.in.cell.minus.yes <- which(randomization1==-1 & respond==1);
  people.in.cell.minus.no <- which(randomization1==-1 &respond==0);
  people.in.cell.plus.no.plus <- which(randomization1==+1 & randomization2==+1);
  people.in.cell.plus.no.minus <- which(randomization1==+1 & randomization2==-1);
  people.in.cell.minus.no.plus <- which(randomization1==-1 & randomization2==+1);
  people.in.cell.minus.no.minus <- which(randomization1==-1 & randomization2==-1);
  if (min(length(people.in.cell.plus.yes),
          length(people.in.cell.plus.no.plus),
          length(people.in.cell.plus.no.minus),
          length(people.in.cell.minus.yes),
          length(people.in.cell.minus.no.plus),
          length(people.in.cell.minus.no.minus))==0) {
    stop("The simulated dataset has nobody in at least one of the six paths.");
  }
  # Generate errors:
  errors <- rmvnorm(n=N,
                    mean=rep(0,3),
                    sigma=sigma*BlockSigma(3,cor.structure,cor.parameter));
  colnames(errors) <- c("time0","time1","time2");
  # Generate Y0:
  mean0 <- rep(NA, N);
  mean0[people.in.cell.yes] <- conditional.mean0.yes;
  mean0[people.in.cell.no] <- conditional.mean0.no;
  Y0 <- mean0 + errors[,"time0"];
  # Generate Y1:
  mean1 <- rep(NA, N);
  mean1[people.in.cell.plus.yes] <- conditional.mean1.plus.yes;
  mean1[people.in.cell.plus.no] <- conditional.mean1.plus.no;
  mean1[people.in.cell.minus.yes] <- conditional.mean1.minus.yes;
  mean1[people.in.cell.minus.no] <- conditional.mean1.minus.no;
  Y1 <- mean1 + errors[,"time1"];
  # Generate Y2:
  mean2 <- rep(NA,N);
  mean2[people.in.cell.plus.yes] <- conditional.mean2.plus.yes;
  mean2[people.in.cell.plus.no.plus] <- conditional.mean2.plus.no.plus;
  mean2[people.in.cell.plus.no.minus] <- conditional.mean2.plus.no.minus;
  mean2[people.in.cell.minus.yes] <- conditional.mean2.minus.yes;
  mean2[people.in.cell.minus.no.plus] <- conditional.mean2.minus.no.plus;
  mean2[people.in.cell.minus.no.minus] <- conditional.mean2.minus.no.minus;
  Y2 <- mean2 + errors[,"time2"];
  # Package results:
  simulated.data <- data.frame(A1=randomization1,  # first treatment randomization;
                               Y0=round(Y0,4),     # outcome at time 0;
                               mean0=mean0,
                               R=respond,          # responder status as binary;
                               Y1=round(Y1,4),     # outcome at time 1;
                               mean1=mean1,
                               A2=randomization2,  # second treatment randomization;
                               Y2=round(Y2,4),     # outcome at time 2;
                               mean2=mean2);
  return(simulated.data);
}