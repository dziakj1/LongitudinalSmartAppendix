DoEstimationKnownWeights <- function(DataWideFormat, 
                                     CorrelationStructure) {
  # Create known weights;
  DataWideFormat$KnownWeight1 <- 2;
  DataWideFormat$KnownWeight2 <- 2*(DataWideFormat$R==0)+1*(DataWideFormat$R==1);  
  # that is, IF (R = 0) THEN known_wt2 = 2; ELSE known_wt2 = 1;
  DataWideFormat$KnownWeight <- DataWideFormat$KnownWeight1 * DataWideFormat$KnownWeight2; 
  # Translate wide-format dataset into a long-format dataset;
  nwaves <- 3; 
  DataLongFormat <- reshape(DataWideFormat, 
                            varying = c("Y0", "Y1", "Y2"), 
                            v.names = "Y",
                            timevar = "time", 
                            times = c(0, 1, 2), 
                            new.row.names = 1:(nwaves*nrow(DataWideFormat)),
                            direction = "long");
  # Create "replications.";
  # Replicate people who got A1=+1 and responded with R=1.  They were not
  # re-randomized, so we have to replicate their data to inform both of
  # the dynamic treatment regimens which they could have received had they
  # been re-randomized.  It is somewhat as if we are creating two clones of
  # each of them and counting each in a different treatment, because in
  # reality it is indistinguishable which one they received.
  DataLongFormat$ActualTime <- DataLongFormat$time; # because we will mess with the time variable;
  RowsToReplicate <- DataLongFormat[which(DataLongFormat$R==1),];
  RowsNotToReplicate <- DataLongFormat[which(DataLongFormat$R==0),];
  PlusOnePseudodata <- RowsToReplicate;
  PlusOnePseudodata$A2 <- 1;
  MinusOnePseudodata <- RowsToReplicate;
  MinusOnePseudodata$A2 <- -1;
  MinusOnePseudodata$time <- MinusOnePseudodata$time + nwaves;  
  # We keep the same subject ID to show that we don't really have all those
  # new participants.  So we have to distinguish the new observations somehow,
  # and so we treat them as new waves of data on the same person.  Although
  # it seems very ad-hoc, this method has been shown to be valid.
  # Create the final analysis dataset including replicates.
  DataForAnalysis <- rbind(PlusOnePseudodata, MinusOnePseudodata, RowsNotToReplicate);
  DataForAnalysis <- DataForAnalysis[order(DataForAnalysis$id,DataForAnalysis$time),] 
  # This sorts by the variables id and time;
  DataForAnalysis$truncTime <- pmin(DataForAnalysis$ActualTime,1);
  # that is, IF ActualTime > 1 THEN truncTime = 1; ELSE truncTime = ActualTime;
  DataForAnalysis$TSince1 <- pmax(DataForAnalysis$ActualTime-1,0);
  # that is, IF ActualTime > 1 THEN TSince1 = ActualTime - 1; ELSE TSince1 = 0; 
  DataForAnalysis$wave <- DataForAnalysis$time + 1; 
  # because time 0 is actually wave 1;
  #  Do analysis with GEE
  if (tolower(CorrelationStructure)=="independence") {
    GEEOutput <- geeglm(formula = Y ~ truncTime +
                          TSince1 +
                          truncTime:A1 + 
                          TSince1:A1 +
                          TSince1:A2 +
                          TSince1:A1:A2,  
                        id=id,
                        weights = KnownWeight,    
                        data=DataForAnalysis,
                        corstr = "independence");
    rho <- 0;
  } else {
    GEEIndependent <- geeglm(formula = Y ~  truncTime +
                               TSince1 +
                               truncTime:A1 + 
                               TSince1:A1 +
                               TSince1:A2 +
                               TSince1:A1:A2,  
                             id=id,  
                             weights = KnownWeight,
                             data=DataForAnalysis,
                             corstr = "independence" ); 
    # "Estimate marginal residual variance under each regime" 
    stopifnot(length(GEEIndependent$resid)==nrow(DataForAnalysis)); # make sure that geeglm didn't drop any rows because of missing data;
    # Create a table of estimated variances indexed by A1, A2, and ActualTime.;
    VarianceEstimatesByRegimenAndTime <- expand.grid(A1=unique(DataForAnalysis$A1),
                                                     A2=unique(DataForAnalysis$A2),
                                                     ActualTime=unique(DataForAnalysis$ActualTime),
                                                     VarianceEstimate=NA);
    for (i in 1:nrow(VarianceEstimatesByRegimenAndTime)) {
      TheseRows <- which( (DataForAnalysis$A1==VarianceEstimatesByRegimenAndTime$A1[i])&
                            (DataForAnalysis$A2==VarianceEstimatesByRegimenAndTime$A2[i])&
                            (DataForAnalysis$ActualTime==VarianceEstimatesByRegimenAndTime$ActualTime[i]) );   
      VarianceEstimatesByRegimenAndTime$VarianceEstimate[i] <- 
        weighted.mean(x=(GEEIndependent$resid[TheseRows]^2),w=DataForAnalysis$KnownWeight[TheseRows]);
    }  
    # Now create a smaller table of estimated variances indexed only by A1 and A2.
    CovarianceEstimatesByRegimen <- expand.grid(A1=unique(DataForAnalysis$A1),
                                                A2=unique(DataForAnalysis$A2), 
                                                VarianceEstimate=NA,
                                                CrossCorrelationEstimate=NA);
    for (i in 1:nrow(CovarianceEstimatesByRegimen)) {
      TheseRows <- which( (VarianceEstimatesByRegimenAndTime$A1==CovarianceEstimatesByRegimen$A1[i])&
                            (VarianceEstimatesByRegimenAndTime$A2==CovarianceEstimatesByRegimen$A2[i])  );   
      CovarianceEstimatesByRegimen$VarianceEstimate[i] <- 
        mean(VarianceEstimatesByRegimenAndTime$VarianceEstimate[TheseRows]);
    }   
    VarianceEstimatePooled <- mean(CovarianceEstimatesByRegimen$VarianceEstimate);
    # "Estimate off-diagonal within-person correlation"
    for (i in 1:nrow(CovarianceEstimatesByRegimen)) {  # regimen index;
      MeanResidualCrossProductsPerSubjectForThisRegimen <- NULL;
      WeightsForThisRegimen <- NULL;
      ThisRegimen <- which( (DataForAnalysis$A1==CovarianceEstimatesByRegimen$A1[i])&
                              (DataForAnalysis$A2==CovarianceEstimatesByRegimen$A2[i]));
      if (tolower(CorrelationStructure)=="exchangeable") {
        for (j in unique(DataForAnalysis$id)) { # subject index; 
          ThisSubjectAndRegimen <- which( (DataForAnalysis$A1==CovarianceEstimatesByRegimen$A1[i])&
                                            (DataForAnalysis$A2==CovarianceEstimatesByRegimen$A2[i]) &
                                            (DataForAnalysis$id==j));
          if (length(ThisSubjectAndRegimen)>0) {
            tempCrossProducts <- crossprod(t(GEEIndependent$resid[ThisSubjectAndRegimen]))[
              upper.tri(crossprod(t(GEEIndependent$resid[ThisSubjectAndRegimen])))]; 
            MeanResidualCrossProductsPerSubjectForThisRegimen <- c(MeanResidualCrossProductsPerSubjectForThisRegimen,
                                                                   mean(tempCrossProducts)); 
            WeightsForThisRegimen <- c(WeightsForThisRegimen, DataForAnalysis[ThisSubjectAndRegimen[1],]$KnownWeight);
            # assumes all observations per subject have the same weight;
          }       
        }
      }
      if (tolower(CorrelationStructure)=="ar-1") {
        for (j in unique(DataForAnalysis$id)) { # subject index; 
          ThisSubjectAndRegimen <- which( (DataForAnalysis$A1==CovarianceEstimatesByRegimen$A1[i])&
                                            (DataForAnalysis$A2==CovarianceEstimatesByRegimen$A2[i]) &
                                            (DataForAnalysis$id==j));
          if (length(ThisSubjectAndRegimen)>0) {
            tempVector <- GEEIndependent$resid[ThisSubjectAndRegimen];
            tempCrossProducts <- tempVector[1:(length(tempVector)-1)] * tempVector[2:length(tempVector)]; 
            MeanResidualCrossProductsPerSubjectForThisRegimen <- c(MeanResidualCrossProductsPerSubjectForThisRegimen,
                                                                   mean(tempCrossProducts)); 
            WeightsForThisRegimen <- c(WeightsForThisRegimen, DataForAnalysis[ThisSubjectAndRegimen[1],]$KnownWeight);
            # assumes all observations per subject have the same weight;
          }       
        }
      }
      CovarianceEstimatesByRegimen$CrossCorrelationEstimate[i] <- weighted.mean(x=MeanResidualCrossProductsPerSubjectForThisRegimen,
                                                                                w=WeightsForThisRegimen)/ 
                 CovarianceEstimatesByRegimen$VarianceEstimate[i];
    } 
    CrossCorrelationEstimatePooled <- mean(CovarianceEstimatesByRegimen$CrossCorrelationEstimate);
    # Print preliminary results;
    # Construct WorkCorr (working correlation matrix) 
    rho <- CrossCorrelationEstimatePooled;
    if (tolower(CorrelationStructure)=="exchangeable") {
      BlockWorkCorr <- diag(as.vector(rep(1-rho,nwaves)))+matrix(rho,nwaves,nwaves);
    }
    if (tolower(CorrelationStructure)=="ar-1") {
      BlockWorkCorr <- matrix(0,nwaves,nwaves);
      for (thisRow in 1:nrow(BlockWorkCorr)) {
        for (thisColumn in 1:ncol(BlockWorkCorr)) {
          BlockWorkCorr[thisRow,thisColumn] <- rho^abs(thisRow-thisColumn);
        }
      }
    }  
    WorkCorr <- rbind(cbind(BlockWorkCorr,0*BlockWorkCorr),cbind(0*BlockWorkCorr,BlockWorkCorr)); 
    WorkCorrAsZCor <- fixed2Zcor(cor.fixed=WorkCorr, 
                             id=DataForAnalysis$id,  
                             waves=DataForAnalysis$wave); 
    GEEOutput <- geeglm(formula = Y ~ truncTime +
                        TSince1 +
                        truncTime:A1 + 
                        TSince1:A1 +
                        TSince1:A2 +
                        TSince1:A1:A2,  
                        id=id,  
                        weights = KnownWeight,
                        data=DataForAnalysis,
                        corstr = "fixed",
                        zcor=WorkCorrAsZCor);   
  }
  # Convert the regression coefficients estimates into the desired linear contrast estimates.;
  GEECoefficients <- coef(GEEOutput);
  GEECovarianceMatrix <- GEEOutput$geese$vbeta;
  colnames(ContrastCoefficients) <- names(coef(GEEOutput));
  ContrastEstimates <- ContrastCoefficients%*%GEECoefficients;  # Note the matrix multiplication;
  ContrastCovarianceMatrix <- ContrastCoefficients%*%GEECovarianceMatrix%*%t(ContrastCoefficients);
  ContrastStdErrors <- sqrt(diag(ContrastCovarianceMatrix)); 
  VarianceEstimate <- summary(GEEOutput)$dispersion["(Intercept)","Estimate"]; 
  #print(GEEOutput);
  return(list(GEEOutput=GEEOutput,
              ContrastEstimates=ContrastEstimates,
              ContrastStdErrors=ContrastStdErrors,
              VarianceEstimate=VarianceEstimate,
              CorrelationEstimate=rho));
}